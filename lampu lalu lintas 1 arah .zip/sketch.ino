void setup()
{
   // menjadikan PIN 4, 5, dan 3 sebagai OUTPUT
   pinMode(5, OUTPUT);
   pinMode(4, OUTPUT);
   pinMode(3, OUTPUT);
}

void loop()
{
   // Menyalakan PIN 5 “Warna merah” (HIGH = Memberi tegangan pada PIN 5)
   digitalWrite(5, HIGH);
   // Pause selama 5 detik
   delay(5000);
   // Mematikan PIN 5 (LOW = Tidak Memberi tegangan pada PIN 5)
   digitalWrite(5, LOW);

   // Menyalakan PIN 4 “Warna kuning” (HIGH = Memberi tegangan pada PIN 4)
   digitalWrite(4, HIGH);
   // Pause selama 2 detik
   delay(2000);
   // Mematikan PIN 4 (LOW = Tidak Memberi tegangan pada PIN 4)
   digitalWrite(4, LOW);

   // Menyalakan PIN 3 “Warna hijau” (HIGH = Memberi tegangan pada PIN 3)
   digitalWrite(3, HIGH);
   // Pause selama 5 detik
   delay(5000);
   // Mematikan PIN 3 (LOW = Tidak Memberi tegangan pada PIN 3)
   digitalWrite(3, LOW);
}
