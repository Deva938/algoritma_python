// Deklarasi Pin LED
const int ledMerah = 13;
const int ledKuning = 12;
const int ledHijau = 11;

void setup() {
  // Mengatur semua pin LED sebagai OUTPUT
    pinMode(ledMerah, OUTPUT);
      pinMode(ledKuning, OUTPUT);
        pinMode(ledHijau, OUTPUT);
        }

        void loop() {
          // 1. Menyalakan LED Merah
            digitalWrite(ledMerah, HIGH);
              digitalWrite(ledKuning, LOW);
                digitalWrite(ledHijau, LOW);
                  delay(1000); // Tunggu 1 detik

                    // 2. Menyalakan LED Kuning
                      digitalWrite(ledMerah, LOW);
                        digitalWrite(ledKuning, HIGH);
                          digitalWrite(ledHijau, LOW);
                            delay(1000); // Tunggu 1 detik

                              // 3. Menyalakan LED Hijau
                                digitalWrite(ledMerah, LOW);
                                  digitalWrite(ledKuning, LOW);
                                    digitalWrite(ledHijau, HIGH);
                                      delay(1000); // Tunggu 1 detik
                                      }